(() => {
    // Anschnall-Meldung + Sounds (eigenstaendig, beruehrt das restliche HUD nicht)
    const el = document.createElement('div');
    el.id = 'sbWarn';
    el.innerHTML =
        '<div class="sb-ico">' +
        '<svg class="i-belt" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
        '<circle cx="12" cy="5" r="2.4"/><path d="M7 21v-7a5 5 0 0 1 10 0v7"/><path d="M8 11l9 8"/></svg>' +
        '<svg class="i-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">' +
        '<path d="M5 12.5l4.5 4.5L19 7.5"/></svg>' +
        '</div>' +
        '<div class="sb-body"><div class="sb-title"></div><div class="sb-text"></div></div>' +
        '<div class="sb-key"></div>' +
        '<div class="sb-bar"><i></i></div>';
    document.body.appendChild(el);

    const q = (s) => el.querySelector(s);
    let hideTimer = null;

    function show(kind, title, text, key, ms) {
        ms = ms || 4000;
        el.classList.remove('warn', 'ok', 'off');
        el.classList.add(kind);
        q('.sb-title').textContent = title || '';
        q('.sb-text').textContent = text || '';
        q('.sb-key').textContent = key || '';
        el.style.setProperty('--sb-dur', ms + 'ms');
        // Zeitbalken neu starten
        el.classList.remove('show');
        void el.offsetWidth;
        el.classList.add('show');
        clearTimeout(hideTimer);
        hideTimer = setTimeout(hide, ms);
    }

    function hide() {
        clearTimeout(hideTimer);
        el.classList.remove('show');
    }

    // =====================================================
    //  Sounds (OGG-Dateien aus html/sounds/)
    //  beltalarm.ogg  = Piepton, solange man nicht angeschnallt ist
    //  carunbuckle.ogg = Anschnallen
    //  carbuckle.ogg   = Abschnallen
    // =====================================================
    const clamp01 = (v, d) => Math.min(Math.max(v == null ? d : v, 0), 1);

    function play(file, vol) {
        try {
            const a = new Audio('sounds/' + file);
            a.volume = clamp01(vol, 0.35);
            const p = a.play();
            if (p && p.catch) p.catch(() => {});
        } catch (e) {
            console.error('[me_hud:seatbelt] sound', e);
        }
    }

    function beep(vol) { play('beltalarm.ogg', vol); }
    function buckleOn(vol) { play('carunbuckle.ogg', vol); }
    function buckleOff(vol) { play('carbuckle.ogg', vol); }

    window.addEventListener('message', (ev) => {
        const m = ev.data;
        if (!m || !m.action || String(m.action).indexOf('sb:') !== 0) return;
        try {
            switch (m.action) {
                case 'sb:warn':
                    show('warn', m.title, m.text, m.key, m.duration);
                    break;
                case 'sb:toggle':
                    show(m.on ? 'ok' : 'off', m.title, m.text, '', 1800);
                    if (m.on) buckleOn(m.volume); else buckleOff(m.volume);
                    break;
                case 'sb:beep':
                    beep(m.volume);
                    break;
                case 'sb:hide':
                    hide();
                    break;
            }
        } catch (err) {
            console.error('[me_hud:seatbelt]', err);
        }
    });
})();
