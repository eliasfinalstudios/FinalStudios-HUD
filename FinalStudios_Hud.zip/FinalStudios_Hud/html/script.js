(() => {
    const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'me_hud';
    const $ = (id) => document.getElementById(id);


    const LANG = {
        de: {
            'Essen:':'Essen:','Wasser:':'Wasser:','Funk:':'Funk:',
            'Servername':'Servername','Uhrzeit':'Uhrzeit','Spieler & ID':'Spieler & ID','Geld':'Geld','Funk':'Funk',
            'Essen & Wasser':'Essen & Wasser','Job':'Job','Tacho':'Tacho','Bargeld:':'Bargeld:','Bankkarte:':'Bankkonto:',
            'Gang':'Gang','Tank':'Tank','Motor':'Motor','Karosserie':'Karosserie','Licht':'Licht','Fernlicht':'Fernlicht',
            'Verriegelt':'Verriegelt','Warnblinker':'Warnblinker','HUD Einstellungen':'HUD Einstellungen',
            'Elemente ziehen · Mausrad = Größe':'Elemente ziehen · Mausrad = Größe','Schließen (ESC)':'Schließen (ESC)',
            'Anzeigen':'Anzeigen','Stil':'Stil','Minimap':'Minimap','Sichtbare Elemente':'Sichtbare Elemente',
            'Verschieben':'Verschieben','Am Raster ausrichten':'Am Raster ausrichten','Akzentfarbe':'Akzentfarbe',
            'Eigene Farbe':'Eigene Farbe','Aussehen':'Aussehen','Hintergrund':'Hintergrund','Eckenrundung':'Eckenrundung',
            'Gesamtgröße':'Gesamtgröße','Form':'Form','Eckig':'Eckig','Rund':'Rund','Sichtbarkeit':'Sichtbarkeit',
            'Nur im Fahrzeug anzeigen':'Nur im Fahrzeug anzeigen','Geschwindigkeit':'Geschwindigkeit',
            'Zurücksetzen':'Zurücksetzen','Abbrechen':'Abbrechen','Speichern':'Speichern',
            'HUD anpassen (Position, Größe, Farbe, Design, Minimap)':'HUD anpassen (Position, Größe, Farbe, Design, Minimap)'
        },
        en: {
            'Essen:':'Food:','Wasser:':'Water:','Funk:':'Radio:',
            'Servername':'Server name','Uhrzeit':'Time','Spieler & ID':'Players & ID','Geld':'Money','Funk':'Radio',
            'Essen & Wasser':'Food & Water','Job':'Job','Tacho':'Speedometer','Bargeld:':'Cash:','Bankkarte:':'Bank:',
            'Gang':'Gear','Tank':'Fuel','Motor':'Engine','Karosserie':'Body','Licht':'Lights','Fernlicht':'High beams',
            'Verriegelt':'Locked','Warnblinker':'Hazard lights','HUD Einstellungen':'HUD Settings',
            'Elemente ziehen · Mausrad = Größe':'Drag elements · Scroll wheel = size','Schließen (ESC)':'Close (ESC)',
            'Anzeigen':'Display','Stil':'Style','Minimap':'Minimap','Sichtbare Elemente':'Visible elements',
            'Verschieben':'Move','Am Raster ausrichten':'Snap to grid','Akzentfarbe':'Accent color',
            'Eigene Farbe':'Custom color','Aussehen':'Appearance','Hintergrund':'Background','Eckenrundung':'Corner radius',
            'Gesamtgröße':'Overall size','Form':'Shape','Eckig':'Square','Rund':'Round','Sichtbarkeit':'Visibility',
            'Nur im Fahrzeug anzeigen':'Show only in vehicle','Geschwindigkeit':'Speed',
            'Zurücksetzen':'Reset','Abbrechen':'Cancel','Speichern':'Save'
        },
        fr: {
            'Essen:':'Faim :','Wasser:':'Soif :','Funk:':'Radio :',
            'Servername':'Nom du serveur','Uhrzeit':'Heure','Spieler & ID':'Joueurs & ID','Geld':'Argent','Funk':'Radio',
            'Essen & Wasser':'Faim & soif','Job':'Métier','Tacho':'Compteur','Bargeld:':'Espèces :','Bankkarte:':'Banque :',
            'Gang':'Vitesse','Tank':'Carburant','Motor':'Moteur','Karosserie':'Carrosserie','Licht':'Feux','Fernlicht':'Phares',
            'Verriegelt':'Verrouillé','Warnblinker':'Feux de détresse','HUD Einstellungen':'Paramètres du HUD',
            'Elemente ziehen · Mausrad = Größe':'Déplacer les éléments · Molette = taille','Schließen (ESC)':'Fermer (ESC)',
            'Anzeigen':'Affichage','Stil':'Style','Minimap':'Minicarte','Sichtbare Elemente':'Éléments visibles',
            'Verschieben':'Déplacement','Am Raster ausrichten':'Aligner sur la grille','Akzentfarbe':'Couleur d’accent',
            'Eigene Farbe':'Couleur personnalisée','Aussehen':'Apparence','Hintergrund':'Arrière-plan','Eckenrundung':'Arrondi des coins',
            'Gesamtgröße':'Taille globale','Form':'Forme','Eckig':'Carré','Rund':'Rond','Sichtbarkeit':'Visibilité',
            'Nur im Fahrzeug anzeigen':'Afficher uniquement en véhicule','Geschwindigkeit':'Vitesse',
            'Zurücksetzen':'Réinitialiser','Abbrechen':'Annuler','Speichern':'Enregistrer'
        },
        es: {
            'Essen:':'Hambre:','Wasser:':'Sed:','Funk:':'Radio:',
            'Servername':'Nombre del servidor','Uhrzeit':'Hora','Spieler & ID':'Jugadores e ID','Geld':'Dinero','Funk':'Radio',
            'Essen & Wasser':'Hambre y sed','Job':'Trabajo','Tacho':'Velocímetro','Bargeld:':'Efectivo:','Bankkarte:':'Banco:',
            'Gang':'Marcha','Tank':'Combustible','Motor':'Motor','Karosserie':'Carrocería','Licht':'Luces','Fernlicht':'Luces largas',
            'Verriegelt':'Bloqueado','Warnblinker':'Luces de emergencia','HUD Einstellungen':'Ajustes del HUD',
            'Elemente ziehen · Mausrad = Größe':'Arrastra elementos · Rueda = tamaño','Schließen (ESC)':'Cerrar (ESC)',
            'Anzeigen':'Mostrar','Stil':'Estilo','Minimap':'Minimapa','Sichtbare Elemente':'Elementos visibles',
            'Verschieben':'Mover','Am Raster ausrichten':'Ajustar a la cuadrícula','Akzentfarbe':'Color de acento',
            'Eigene Farbe':'Color personalizado','Aussehen':'Apariencia','Hintergrund':'Fondo','Eckenrundung':'Redondez de esquinas',
            'Gesamtgröße':'Tamaño general','Form':'Forma','Eckig':'Cuadrado','Rund':'Redondo','Sichtbarkeit':'Visibilidad',
            'Nur im Fahrzeug anzeigen':'Mostrar solo en vehículo','Geschwindigkeit':'Velocidad',
            'Zurücksetzen':'Restablecer','Abbrechen':'Cancelar','Speichern':'Guardar'
        },
        pl: {
            'Essen:':'Głód:','Wasser:':'Pragnienie:','Funk:':'Radio:',
            'Servername':'Nazwa serwera','Uhrzeit':'Godzina','Spieler & ID':'Gracze i ID','Geld':'Pieniądze','Funk':'Radio',
            'Essen & Wasser':'Głód i pragnienie','Job':'Praca','Tacho':'Prędkościomierz','Bargeld:':'Gotówka:','Bankkarte:':'Bank:',
            'Gang':'Bieg','Tank':'Paliwo','Motor':'Silnik','Karosserie':'Karoseria','Licht':'Światła','Fernlicht':'Światła drogowe',
            'Verriegelt':'Zablokowany','Warnblinker':'Światła awaryjne','HUD Einstellungen':'Ustawienia HUD',
            'Elemente ziehen · Mausrad = Größe':'Przeciągnij elementy · Kółko = rozmiar','Schließen (ESC)':'Zamknij (ESC)',
            'Anzeigen':'Wyświetlanie','Stil':'Styl','Minimap':'Minimapa','Sichtbare Elemente':'Widoczne elementy',
            'Verschieben':'Przesuwanie','Am Raster ausrichten':'Przyciągaj do siatki','Akzentfarbe':'Kolor akcentu',
            'Eigene Farbe':'Własny kolor','Aussehen':'Wygląd','Hintergrund':'Tło','Eckenrundung':'Zaokrąglenie rogów',
            'Gesamtgröße':'Całkowity rozmiar','Form':'Kształt','Eckig':'Kwadratowy','Rund':'Okrągły','Sichtbarkeit':'Widoczność',
            'Nur im Fahrzeug anzeigen':'Pokazuj tylko w pojeździe','Geschwindigkeit':'Prędkość',
            'Zurücksetzen':'Resetuj','Abbrechen':'Anuluj','Speichern':'Zapisz'
        }
    };
    let currentLanguage = 'de';
    function translateUI(language) {
        currentLanguage = LANG[language] ? language : 'de';
        const dict = LANG[currentLanguage];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        for (const node of nodes) {
            const raw = node.nodeValue;
            const trimmed = raw.trim();
            if (dict[trimmed]) node.nodeValue = raw.replace(trimmed, dict[trimmed]);
        }
        document.querySelectorAll('[data-label]').forEach(el => {
            const original = el.getAttribute('data-label');
            if (!el.dataset.originalLabel) el.dataset.originalLabel = original;
            el.setAttribute('data-label', dict[el.dataset.originalLabel] || el.dataset.originalLabel);
        });
        document.documentElement.lang = currentLanguage;
    }

    const NAME_KEYS = { logo: 'Servername', clock: 'Uhrzeit', info: 'Spieler & ID', money: 'Geld', radio: 'Funk', status: 'Essen & Wasser', job: 'Job', vehicle: 'Tacho' };
    const NAMES = { ...NAME_KEYS };
    const KEYS = Object.keys(NAMES);
    const FALLBACK_MM = { l: 0.02, t: 0.79, r: 0.16, b: 0.97 };

    let defaults = null;
    let layout = null;
    let saved = null;
    let clockMode = 'real';
    let showMax = false;
    let editing = false;
    let lastData = null;

    const clone = (o) => JSON.parse(JSON.stringify(o));
    const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
    const isNum = (v) => typeof v === 'number' && isFinite(v);
    const pad = (n) => String(n).padStart(2, '0');
    const validColor = (c) => (typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c) ? c.toLowerCase() : null);
    const PRESETS = ['#f2b72b', '#ff8a3d', '#ff5d5d', '#ff5fa2', '#b072ff', '#4f8cff', '#3fb0ea', '#3ddc97', '#e8ecef'];
    let unitFromGame = 'kmh';

    function post(name, body) {
        return fetch(`https://${RES}/${name}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify(body || {})
        }).catch(() => {});
    }



    function merge(def, usr, defMinimap) {
        const out = {
            scale: isNum(def.scale) ? def.scale : 1,
            minimap: { shape: 'square', onlyVehicle: false },
            v: 3,
            style: { accent: '#f2b72b', bg: 0, radius: 14, unit: 'kmh' },
            elements: {}
        };
        const ds = def.style || {};
        const us = (usr && usr.v === 3 && usr.style) || {};
        out.style.accent = validColor(us.accent) || validColor(ds.accent) || out.style.accent;
        out.style.bg = clamp(isNum(us.bg) ? us.bg : (isNum(ds.bg) ? ds.bg : 0), 0, 80);
        out.style.radius = clamp(isNum(us.radius) ? us.radius : (isNum(ds.radius) ? ds.radius : 14), 0, 26);
        out.style.unit = (us.unit || unitFromGame) === 'mph' ? 'mph' : 'kmh';
        if (usr && isNum(usr.scale)) out.scale = clamp(usr.scale, 0.7, 1.3);

        const dm = defMinimap || {};
        const um = (usr && usr.minimap) || {};
        out.minimap.shape = (um.shape || dm.shape) === 'round' ? 'round' : 'square';
        out.minimap.onlyVehicle = typeof um.onlyVehicle === 'boolean' ? um.onlyVehicle : !!dm.onlyVehicle;

        for (const k of KEYS) {
            const d = (def.elements && def.elements[k]) || {};
            const u = (usr && usr.elements && usr.elements[k]) || {};
            const custom = isNum(u.x) && isNum(u.y);
            out.elements[k] = {
                x: custom ? clamp(u.x, 0, 100) : null,
                y: custom ? clamp(u.y, 0, 100) : null,
                s: clamp(isNum(u.s) ? u.s : (isNum(d.s) ? d.s : 1), 0.6, 1.8),
                visible: typeof u.visible === 'boolean' ? u.visible : d.visible !== false
            };
        }
        return out;
    }

 

    function autoLayout() {
        const W = innerWidth;
        const H = innerHeight;
        const mm = (lastData && lastData.mm) || FALLBACK_MM;
        const E = layout.elements;
        const fs = H * 0.012 * layout.scale;

        const isAuto = (k) => E[k].x === null || E[k].y === null;
        const rect = (k) => $(k).getBoundingClientRect();
        const put = (k, left, top) => {
            const n = $(k);
            n.style.left = ((left / W) * 100).toFixed(3) + '%';
            n.style.top = ((top / H) * 100).toFixed(3) + '%';
        };

        const marginX = Math.max(mm.l * W, W * 0.01);
        const marginT = Math.max((1 - mm.b) * H, H * 0.015);
        const R = W - marginX;
        const gap = fs * 0.6;

  
        let rowBottom = marginT;
        let rowUsed = false;
        let logoLeft = R;
        let logoPlaced = false;

        if (isAuto('logo')) {
            const r = rect('logo');
            if (r.width > 0) {
                logoLeft = R - r.width;
                put('logo', logoLeft, marginT);
                logoPlaced = true;
                rowUsed = true;
                rowBottom = Math.max(rowBottom, marginT + r.height);
            }
        }
        if (isAuto('clock')) {
            const r = rect('clock');
            if (r.width > 0) {
                const right = logoPlaced ? logoLeft - fs * 1.6 : R;
                put('clock', right - r.width, marginT);
                rowUsed = true;
                rowBottom = Math.max(rowBottom, marginT + r.height);
            }
        }

        let y = rowUsed ? rowBottom + gap * 1.2 : marginT;
        for (const k of ['info', 'money', 'radio']) {
            if (!isAuto(k)) continue;
            const r = rect(k);
            if (r.width <= 0) continue;
            put(k, R - r.width, y);
            y += r.height + (k === 'money' ? gap * 1.6 : gap);
        }

        // links unten: an der Minimap ausgerichtet
        const mmL = Math.max(mm.l * W, W * 0.008);
        const mmT = mm.t * H;
        const mmR = mm.r * W;
        const mmB = mm.b * H;

       
        const stackTop = mmT;
        if (isAuto('job')) {
            const r = rect('job');
            if (r.width > 0) {
                put('job', mmR + gap, mmT);
            }
        }
        if (isAuto('status')) {
            const r = rect('status');
            if (r.width > 0) put('status', mmL, stackTop - fs * 1.4 - r.height);
        }

        
        if (isAuto('vehicle')) {
            const r = rect('vehicle');
            if (r.width > 0) put('vehicle', R - r.width, mmB - r.height);
        }
    }

    function apply() {
        if (!layout) return;
        const root = document.documentElement.style;
        root.setProperty('--g', layout.scale);
        root.setProperty('--accent', layout.style.accent);
        root.setProperty('--bg-a', (layout.style.bg / 100).toFixed(2));
        root.setProperty('--r', layout.style.bg > 0 ? layout.style.radius + 'px' : '0px');
        root.setProperty('--pad', layout.style.bg > 0 ? '.55em .85em' : '0');
        $('speedUnit').textContent = layout.style.unit === 'mph' ? 'mph' : 'km/h';
        for (const k of KEYS) {
            const e = layout.elements[k];
            const n = $(k);
            n.style.setProperty('--s', e.s);
            n.classList.toggle('off', !e.visible);
            if (e.x !== null && e.y !== null) {
                n.style.left = e.x + '%';
                n.style.top = e.y + '%';
            }
        }
        autoLayout();
    }

    function keepInside(k) {
        const e = layout.elements[k];
        if (e.x === null) return;
        const r = $(k).getBoundingClientRect();
        if (r.width === 0) return;
        const maxX = Math.max(0, ((innerWidth - r.width) / innerWidth) * 100);
        const maxY = Math.max(0, ((innerHeight - r.height) / innerHeight) * 100);
        e.x = +clamp(e.x, 0, maxX).toFixed(2);
        e.y = +clamp(e.y, 0, maxY).toFixed(2);
    }



    const fmtMoney = (n) => (n < 0 ? '-' : '') + '€' + Math.abs(Math.round(n || 0)).toLocaleString('de-DE');
    const setText = (id, v) => {
        const n = $(id);
        if (n.textContent !== String(v)) n.textContent = v;
    };

    function setGrade(id, grade) {
        const n = $(id);
        const g = String(grade || '');
        if (n.dataset.v === g) return;
        n.dataset.v = g;
        n.textContent = '';
        const mt = g.match(/^(.*?)(\s*\[[^\]]*\])$/);
        if (mt) {
            n.append(document.createTextNode(mt[1]));
            const s = document.createElement('span');
            s.className = 'dim';
            s.textContent = mt[2].startsWith(' ') ? mt[2] : ' ' + mt[2];
            n.append(s);
        } else {
            n.textContent = g;
        }
    }

    function setBar(id, pct, lowAt) {
        const b = $(id);
        const p = clamp(Math.round(pct), 0, 100);
        b.querySelector('.fill').style.width = p + '%';
        b.querySelector('.bv').textContent = p + '%';
        b.classList.toggle('low', p <= (lowAt || 15));
    }

    function tickClock() {
        if (clockMode === 'game') return;
        const n = new Date();
        setText('clockTime', `${pad(n.getHours())}:${pad(n.getMinutes())}`);
        setText('clockDate', `${pad(n.getDate())}.${pad(n.getMonth() + 1)}.${n.getFullYear()}`);
    }

    function updateVehicle(v) {
        setText('speed', v.speed);
        $('gearWrap').classList.toggle('hide', !v.gear);
        setText('gear', v.gear);
        $('rpm').style.width = v.rpm + '%';
        $('rpm').classList.toggle('red', v.rpm >= 88);

        $('r-fuel').classList.toggle('hide', v.fuel < 0);
        if (v.fuel >= 0) setBar('r-fuel', v.fuel, 15);
        setBar('r-engine', v.engine, 25);
        setBar('r-body', v.body, 25);

        $('indL').classList.toggle('on', !!v.indL);
        $('indR').classList.toggle('on', !!v.indR);

        $('f-engine').classList.toggle('on', !!v.engineOn);
        $('f-light').classList.toggle('on', v.lights >= 1);
        $('f-high').classList.toggle('on', v.lights === 2);
        $('f-lock').classList.toggle('on', !!v.locked);
        $('f-hazard').classList.toggle('on', !!(v.indL && v.indR));
    }

    function update(d) {
        lastData = d;
        if (!layout) return;

        $('hud').classList.toggle('hidden', !d.visible && !editing);

        setText('players', d.players);
        setText('maxPlayers', showMax && d.maxPlayers > 0 ? '/' + d.maxPlayers : '');
        setText('pid', d.id);

        const hasVoice = d.voiceMode > 0;
        $('vol').classList.toggle('hide', !hasVoice);
        $('mic').classList.toggle('hide', !hasVoice);
        $('mic').classList.toggle('talking', !!d.talking);
        [...$('vol').children].forEach((bar, i) => bar.classList.toggle('on', i < d.voiceMode));

        setText('cash', fmtMoney(d.cash));
        setText('bank', fmtMoney(d.bank));

        setBar('b-hunger', d.hunger);
        setBar('b-thirst', d.thirst);

        $('job').classList.toggle('gone', !d.job);
        setText('jobName', d.job);
        setGrade('jobGrade', d.grade);
        $('job2Block').classList.toggle('hide', !d.job2);
        setText('job2Name', d.job2 || '');
        setGrade('job2Grade', d.grade2 || '');

        $('radio').classList.toggle('gone', d.radio < 0);
        setText('radioVal', d.radio > 0 ? d.radio : '-');

        $('vehicle').classList.toggle('gone', !d.inVehicle);
        if (d.veh) updateVehicle(d.veh);

        if (clockMode === 'game') {
            setText('clockTime', d.time);
            setText('clockDate', d.date);
        }

        scheduleApply();
    }

    let applyQueued = false;
    function scheduleApply() {
        if (applyQueued) return;
        applyQueued = true;
        requestAnimationFrame(() => {
            applyQueued = false;
            try { apply(); } catch (err) { console.error('[me_hud]', err); }
        });
    }



    function buildToggles() {
        const box = $('toggles');
        box.innerHTML = '';
        for (const k of KEYS) {
            const label = document.createElement('label');
            label.className = 'switch-row';
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.checked = layout.elements[k].visible;
            input.addEventListener('change', () => {
                layout.elements[k].visible = input.checked;
                apply();
            });
            const txt = document.createElement('span');
            txt.textContent = (LANG[currentLanguage] || LANG.de)[NAME_KEYS[k]] || NAME_KEYS[k];
            label.append(txt, input, document.createElement('i'));
            box.append(label);
        }
    }

    function paintRanges() {
        document.querySelectorAll('#panel input[type="range"]').forEach((r) => {
            const p = ((r.value - r.min) / (r.max - r.min)) * 100;
            r.style.setProperty('--v', p + '%');
        });
    }

    function syncControls() {
        const pct = Math.round(layout.scale * 100);
        $('scale').value = pct;
        $('scaleVal').textContent = pct + '%';
        $('onlyVeh').checked = layout.minimap.onlyVehicle;
        $('bg').value = layout.style.bg;
        $('bgVal').textContent = layout.style.bg + '%';
        $('radius').value = layout.style.radius;
        $('radiusVal').textContent = layout.style.radius;
        $('accentPick').value = layout.style.accent;
        document.querySelectorAll('#swatches button').forEach((b) => {
            b.classList.toggle('active', b.dataset.color === layout.style.accent);
        });
        document.querySelectorAll('#unitSeg button').forEach((b) => {
            b.classList.toggle('active', b.dataset.unit === layout.style.unit);
        });
        paintRanges();
        document.querySelectorAll('#shapeSeg button').forEach((b) => {
            b.classList.toggle('active', b.dataset.shape === layout.minimap.shape);
        });
    }

    function pushMinimap() {
        post('minimap', layout.minimap);
    }

    function setEditing(state) {
        editing = state;
        document.body.classList.toggle('editing', state);
        if (state && layout) {
            $('hud').classList.remove('hidden');
            buildToggles();
            syncControls();
            apply();
        } else {
            if (layout && saved) {
                layout = clone(saved);
                apply();
            }
            if (lastData) update(lastData);
        }
    }

        function buildSwatches() {
        const box = $('swatches');
        box.innerHTML = '';
        PRESETS.forEach((c) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.dataset.color = c;
            b.style.setProperty('--sw', c);
            b.title = c;
            b.addEventListener('click', () => {
                layout.style.accent = c;
                syncControls();
                apply();
            });
            box.append(b);
        });
    }

    $('accentPick').addEventListener('input', (ev) => {
        layout.style.accent = validColor(ev.target.value) || layout.style.accent;
        syncControls();
        apply();
    });

    $('bg').addEventListener('input', (ev) => {
        layout.style.bg = clamp(+ev.target.value, 0, 80);
        $('bgVal').textContent = layout.style.bg + '%';
        apply();
    });

    $('radius').addEventListener('input', (ev) => {
        layout.style.radius = clamp(+ev.target.value, 0, 26);
        $('radiusVal').textContent = layout.style.radius;
    });
    $('radius').addEventListener('input', apply);

    document.querySelectorAll('#unitSeg button').forEach((b) => {
        b.addEventListener('click', () => {
            layout.style.unit = b.dataset.unit;
            syncControls();
            apply();
            post('unit', { unit: layout.style.unit });
        });
    });

    $('scale').addEventListener('input', (ev) => {
        layout.scale = clamp(ev.target.value / 100, 0.7, 1.3);
        $('scaleVal').textContent = ev.target.value + '%';
        apply();
        KEYS.forEach(keepInside);
        apply();
    });

    document.querySelectorAll('#shapeSeg button').forEach((b) => {
        b.addEventListener('click', () => {
            layout.minimap.shape = b.dataset.shape;
            syncControls();
            pushMinimap();
        });
    });

    $('onlyVeh').addEventListener('change', (ev) => {
        layout.minimap.onlyVehicle = ev.target.checked;
        pushMinimap();
    });

    $('btnSave').addEventListener('click', () => {
        KEYS.forEach(keepInside);
        apply();
        saved = clone(layout);
        post('save', layout);
    });

    $('btnReset').addEventListener('click', () => {
        layout = merge(defaults, null, defaultMinimap);
        post('unit', { unit: layout.style.unit });
        apply();
        buildToggles();
        syncControls();
        pushMinimap();
    });

    $('btnCancel').addEventListener('click', cancel);

    function cancel() {
        layout = clone(saved);
        apply();
        post('minimap', layout.minimap);
        post('unit', { unit: layout.style.unit });
        post('close');
    }

    document.addEventListener('keydown', (ev) => {
        if (editing && ev.key === 'Escape') cancel();
    });



    let drag = null;

    document.addEventListener('mousedown', (ev) => {
        if (!editing || ev.button !== 0) return;
        const el = ev.target.closest('.el');
        if (!el) return;
        const r = el.getBoundingClientRect();
        drag = { el, dx: ev.clientX - r.left, dy: ev.clientY - r.top, w: r.width, h: r.height };
        el.classList.add('dragging');
        ev.preventDefault();
    });

    document.addEventListener('mousemove', (ev) => {
        if (!drag) return;
        const maxX = Math.max(0, ((innerWidth - drag.w) / innerWidth) * 100);
        const maxY = Math.max(0, ((innerHeight - drag.h) / innerHeight) * 100);
        let px = ((ev.clientX - drag.dx) / innerWidth) * 100;
        let py = ((ev.clientY - drag.dy) / innerHeight) * 100;
        if ($('snap').checked) {
            px = Math.round(px);
            py = Math.round(py);
        }
        const e = layout.elements[drag.el.id];
        e.x = +clamp(px, 0, maxX).toFixed(2);
        e.y = +clamp(py, 0, maxY).toFixed(2);
        apply();
    });

    document.addEventListener('mouseup', () => {
        if (!drag) return;
        drag.el.classList.remove('dragging');
        drag = null;
    });

    document.addEventListener('wheel', (ev) => {
        if (!editing) return;
        const el = ev.target.closest('.el');
        if (!el) return;
        const e = layout.elements[el.id];
        e.s = +clamp(e.s + (ev.deltaY < 0 ? 0.05 : -0.05), 0.6, 1.8).toFixed(2);
        apply();
        keepInside(el.id);
        apply();
    }, { passive: true });

    document.querySelectorAll('#panel input[type="range"]').forEach((r) => {
        r.addEventListener('input', paintRanges);
    });

    $('btnClose').addEventListener('click', () => cancel());

    document.querySelectorAll('#nav button').forEach((b) => {
        b.addEventListener('click', () => {
            document.querySelectorAll('#nav button').forEach((x) => x.classList.toggle('active', x === b));
            document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.id === 'tab-' + b.dataset.tab));
        });
    });

    window.addEventListener('resize', apply);



    let defaultMinimap = null;

    window.addEventListener('message', (ev) => {
        const m = ev.data;
        if (!m || !m.action) return;
        try {
        switch (m.action) {
            case 'init':
                translateUI(m.language || 'de');
                for (const k of KEYS) NAMES[k] = (LANG[currentLanguage] || LANG.de)[NAME_KEYS[k]] || NAME_KEYS[k];
                defaults = m.defaults;
                defaultMinimap = m.defaultMinimap;
                clockMode = m.clockMode || 'real';
                showMax = !!m.showMax;
                unitFromGame = m.speedUnit === 'mph' ? 'mph' : 'kmh';
                layout = merge(defaults, m.layout, defaultMinimap);
                saved = clone(layout);
                buildSwatches();
                $('logo').classList.toggle('gone', m.showName === false);
                if (m.serverName) {
                    const parts = String(m.serverName).trim().split(/\s+/);
                    $('logoA').textContent = parts.shift() || '';
                    $('logoB').textContent = parts.join(' ');
                }
                tickClock();
                if (lastData) update(lastData);
                else apply();
                break;
            case 'edit':
                setEditing(!!m.state);
                break;
            case 'update':
                update(m.data);
                break;
        }
        } catch (err) {
            console.error('[me_hud]', err);
        }
    });

    setInterval(tickClock, 1000);
    post('ready');
})();
