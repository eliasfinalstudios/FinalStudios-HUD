# Final Studios HUD

**Ein modernes und individuell anpassbares HUD für FiveM.**

Das Final Studios HUD bietet eine übersichtliche Darstellung der wichtigsten Spieler- und Fahrzeuginformationen. Durch die integrierten Anpassungsmöglichkeiten kann jeder Spieler sein HUD nach eigenen Vorstellungen gestalten.

## Funktionen

- Anzeige von Servername und Uhrzeit
- Spieler-ID und aktuelle Spieleranzahl
- Bargeld und Bankguthaben
- Aktueller Job und Dienstgrad
- Hunger- und Durstanzeige
- Funkstatus und Mikrofonanzeige
- Fahrzeug-Tacho mit Geschwindigkeitsanzeige
- Tankfüllstand
- Motor- und Karosseriezustand
- Anzeige von Fahrzeugbeleuchtung und Verriegelung
- Individuell anpassbare Minimap
- Eckige und runde Minimap
- Minimap nur im Fahrzeug anzeigen

## HUD-Anpassung

Über den Befehl `/hud` kann jeder Spieler sein HUD individuell konfigurieren.

Folgende Anpassungen stehen zur Verfügung:

- HUD-Elemente verschieben
- Größe einzelner Elemente verändern
- Sichtbarkeit einzelner Elemente einstellen
- Gesamtgröße anpassen
- Akzentfarbe frei auswählen
- Hintergrund und Transparenz einstellen
- Eckenrundung verändern
- Minimap-Form auswählen
- Minimap-Sichtbarkeit konfigurieren

Die persönlichen Einstellungen werden gespeichert und bleiben auch nach einem erneuten Verbinden erhalten.

## Anschnall-System

- Beim Einsteigen erscheint rechts für ca. 4 Sekunden eine Warnung
- Warnton (Piepen), solange man nicht angeschnallt ist
- Mit `B` an- und abschnallen (Taste in den FiveM-Einstellungen änderbar), jeweils mit eigenem Ton
- Angeschnallt fliegt man bei Unfällen nicht durch die Scheibe
- Einstellungen in `Config.Seatbelt` (Taste, Dauer, Lautstärke, Fahrzeugklassen)
- Export: `exports['FinalStudios_Hud']:isBuckled()`

## Mehrsprachigkeit

Das Final Studios HUD unterstützt mehrere Sprachen.

Verfügbare Sprachen:

- Deutsch
- Englisch
- Französisch
- Spanisch
- Polnisch

Die gewünschte Sprache kann direkt in der `config.lua` eingestellt werden.

```lua
Config.Language = 'de'
```

Verfügbare Sprachcodes: `de`, `en`, `fr`, `es`, `pl`.

## Konfiguration

In der `config.lua` können verschiedene Einstellungen vorgenommen werden.

Dazu gehören unter anderem:

- HUD-Sprache
- Servername
- Aktualisierungsintervalle
- Geschwindigkeitsanzeige (KM/H oder MPH)
- Tankanzeige
- Voice-System
- Job-Anzeige
- Minimap-Einstellungen
- Standardfarben und HUD-Größen

## Voraussetzungen

- FiveM Server
- ESX Legacy
- es_extended
- esx_status für Hunger und Durst
- pma-voice für die Funkintegration

## Resource starten

In der `server.cfg` eintragen:

```cfg
ensure FinalStudios_Hud
```

Der Resource-Ordner muss entsprechend `FinalStudios_Hud` heißen.

## Entwickler

**Final Studios**

FiveM Development & Custom Resources

© Final Studios – Alle Rechte vorbehalten.