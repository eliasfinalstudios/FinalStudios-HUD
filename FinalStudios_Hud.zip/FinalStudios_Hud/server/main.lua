local function getCounts()
    return GetNumPlayerIndices(), GetConvarInt('sv_maxclients', 48)
end

local function broadcast()
    local count, max = getCounts()
    TriggerClientEvent('me_hud:players', -1, count, max)
end

CreateThread(function()
    while true do
        broadcast()
        Wait(Config.PlayerCountInterval)
    end
end)

RegisterNetEvent('me_hud:requestPlayers', function()
    local src = source
    local count, max = getCounts()
    TriggerClientEvent('me_hud:players', src, count, max)
end)

AddEventHandler('playerJoining', function()
    SetTimeout(1500, broadcast)
end)

AddEventHandler('playerDropped', function()
    SetTimeout(1500, broadcast)
end)
