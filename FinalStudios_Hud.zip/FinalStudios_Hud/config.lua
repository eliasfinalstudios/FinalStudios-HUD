Config = {}

-- HUD-Sprache: 'de', 'en', 'fr', 'es','pl'
Config.Language = 'de'

-- Befehl, mit dem jeder Spieler sein HUD anpassen kann
Config.Command = 'hud'

-- Servername oben rechts (erstes Wort gelb, Rest weiß)
Config.ShowServerName = true
Config.ServerName = 'Final Studios'

-- Wie oft das HUD aktualisiert wird (ms)
Config.UpdateInterval = 200
Config.VehicleUpdateInterval = 100   -- im Fahrzeug schneller, damit der Tacho flüssig läuft

-- Wie oft der Server die Spielerzahl an alle sendet (ms)
Config.PlayerCountInterval = 5000
Config.ShowMaxPlayers = false        -- true = "12/64", false = nur "12" (wie im Vorbild)

-- 'real' = echte Uhrzeit des Spielers, 'game' = GTA-Spielzeit
Config.ClockMode = 'real'

-- 'kmh' oder 'mph'
Config.SpeedUnit = 'kmh'

-- Tankanzeige im Fahrzeug (nutzt GetVehicleFuelLevel, läuft mit den meisten Tank-Scripts)
Config.ShowFuel = true

-- 'pma-voice' oder 'none' (bei 'none' werden Funk, Lautstärke und Mikrofon ausgeblendet)
Config.Voice = 'pma-voice'

-- Essen/Wasser: Falls mehrere Status-Quellen gleichzeitig unterschiedliche Werte melden,
-- zeigt das HUD diesen Wert an: 'high' = den höheren (die neuere, frisch geladene Quelle), 'low' = den niedrigeren.
Config.StatusPick = 'high'

-- Namen deiner ESX-Konten
Config.Accounts = {
    cash = 'money',
    bank = 'bank'
}

-- Job-Anzeige
Config.HideUnemployed = false        -- false = Job-Anzeige immer sichtbar (auch ohne Job)
Config.UnemployedJob = 'unemployed'
Config.ShowGradeNumber = true        -- "Auszubildender [1]"

-- GTA-Standard-HUD-Elemente, die versteckt werden
-- 3/4 = Bargeld, 13 = Geld-Änderung, 6 = Fahrzeugname, 7 = Gebiet, 8 = Fahrzeugklasse, 9 = Straße
Config.HideComponents = { 3, 4, 6, 7, 8, 9, 13 }

-- Minimap vom HUD verwalten lassen
-- shape: 'square' (eckig, Standard wie im Vorbild) oder 'round' (rund)
-- onlyVehicle: true = Minimap nur im Fahrzeug anzeigen
-- Jeder Spieler kann beides selbst in /hud umstellen.
Config.ManageRadar = true
-- roundScale: Größe der runden Minimap (1.0 = große Standardrunde, 0.6 = klein). Bei Bedarf feinjustieren.
Config.Minimap = {
    shape = 'square',
    onlyVehicle = false,
    roundScale = 0.6
}

-- Standard-Einstellungen der Elemente.
-- Die Positionen werden automatisch passend zur Minimap berechnet (gerade und bündig),
-- solange der Spieler nichts verschiebt. Hier nur Größe und Sichtbarkeit.
-- style: Standard-Aussehen (jeder Spieler kann es in /hud ändern)
--   accent = Akzentfarbe, bg = Hintergrund-Deckkraft in % (0 = altes HUD-Design ohne Hintergrund), radius = Eckenrundung in px
Config.Defaults = {
    scale = 1.0,
    style = { accent = '#f2b72b', bg = 0, radius = 14 },
    elements = {
        logo    = { s = 1.0, visible = true },
        clock   = { s = 1.0, visible = true },
        info    = { s = 1.0, visible = true },
        money   = { s = 1.0, visible = true },
        radio   = { s = 1.0, visible = true },
        status  = { s = 1.0, visible = true },
        job     = { s = 1.0, visible = true },
        vehicle = { s = 1.0, visible = true }
    }
}


-- ============================================================
-- Anschnall-System
-- ============================================================
Config.Seatbelt = {
    Enabled = true,
    Key = 'B',                    -- Standardtaste (jeder Spieler kann sie in den FiveM-Tasteneinstellungen aendern)

    WarnDuration = 4000,          -- Warnung rechts beim Einsteigen (ms), 3000-5000 empfohlen
    BeepInterval = 1800,          -- Abstand des Warntons, solange man nicht angeschnallt ist (ms)
    Volume = 0.35,                -- Lautstaerke der Toene (0.0 - 1.0)

    RequireEngine = true,         -- Warnton nur bei laufendem Motor
    MinSpeed = 0,                 -- Warnton erst ab dieser Geschwindigkeit (km/h), 0 = immer
    BlockWindscreen = true,       -- angeschnallt = man fliegt bei einem Unfall nicht durch die Scheibe

    -- Fahrzeugklassen ohne Gurt: 8 Motorraeder, 13 Fahrraeder, 14 Boote, 15 Helis, 16 Flugzeuge, 21 Zuege
    ExcludedClasses = { [8] = true, [13] = true, [14] = true, [15] = true, [16] = true, [21] = true },

    Texts = {
        de = { title = 'Bitte anschnallen!', text = 'Sicherheit geht vor. Druecke {key}, um dich anzuschnallen.', on = 'Angeschnallt', onText = 'Gurt angelegt. Gute Fahrt!', off = 'Abgeschnallt', offText = 'Gurt geloest.' },
        en = { title = 'Fasten your seatbelt!', text = 'Safety first. Press {key} to buckle up.', on = 'Buckled up', onText = 'Seatbelt on. Drive safe!', off = 'Unbuckled', offText = 'Seatbelt off.' },
        fr = { title = 'Attachez votre ceinture !', text = 'La securite avant tout. Appuyez sur {key} pour boucler.', on = 'Ceinture attachee', onText = 'Ceinture bouclee. Bonne route !', off = 'Ceinture detachee', offText = 'Ceinture retiree.' },
        es = { title = 'Abrochate el cinturon!', text = 'La seguridad primero. Pulsa {key} para abrocharte.', on = 'Cinturon puesto', onText = 'Cinturon abrochado. Buen viaje!', off = 'Cinturon quitado', offText = 'Cinturon desabrochado.' },
        pl = { title = 'Zapnij pasy!', text = 'Bezpieczenstwo przede wszystkim. Nacisnij {key}, aby zapiac pasy.', on = 'Pasy zapiete', onText = 'Pasy zapiete. Szerokiej drogi!', off = 'Pasy odpiete', offText = 'Pasy odpiete.' }
    }
}
