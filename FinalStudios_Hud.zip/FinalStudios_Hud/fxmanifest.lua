fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Final Studios'
description 'FS Hud - Erweiterte FiveM HUD'
version '1.7.0'

shared_script 'config.lua'

client_scripts {
    'client/main.lua',
    'client/seatbelt.lua'
}
server_script 'server/main.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/seatbelt.css',
    'html/seatbelt.js',
    'html/img/circlemask.png',
    'html/sounds/beltalarm.ogg',
    'html/sounds/carbuckle.ogg',
    'html/sounds/carunbuckle.ogg'
}

dependencies {
    'es_extended'
}
