-- Anschnall-System (eigenstaendig, aendert nichts am restlichen HUD)
local cfg = Config.Seatbelt
if not cfg or not cfg.Enabled then return end

local buckled = false
local curVeh = 0
local lastBeep = 0
local lastToggle = 0

local function texts()
    return cfg.Texts[Config.Language or 'de'] or cfg.Texts.de
end

local function fill(str)
    return (str:gsub('{key}', cfg.Key))
end

local function ui(action, data)
    data = data or {}
    data.action = action
    SendNUIMessage(data)
end

local function setBuckled(value, silent)
    if buckled == value then return end
    buckled = value
    LocalPlayer.state:set('seatbelt', value, true)
    if cfg.BlockWindscreen then
        SetPedConfigFlag(PlayerPedId(), 32, not value)
    end
    if not silent then
        local t = texts()
        ui('sb:toggle', {
            on = value,
            title = value and t.on or t.off,
            text = value and t.onText or t.offText,
            volume = cfg.Volume
        })
    end
end

local function isEligible(veh)
    return veh ~= 0 and not cfg.ExcludedClasses[GetVehicleClass(veh)]
end

local function toggle()
    if curVeh == 0 then return end
    if IsPauseMenuActive() then return end
    local now = GetGameTimer()
    if now - lastToggle < 400 then return end
    lastToggle = now
    setBuckled(not buckled)
end

RegisterCommand('fs_seatbelt', toggle, false)
RegisterKeyMapping('fs_seatbelt', 'Anschnallen / Abschnallen', 'keyboard', cfg.Key)

exports('isBuckled', function() return buckled end)

-- Mit angelegtem Gurt den normalen Fahrzeugausstieg blockieren.
-- Die Sperre wird pro Frame gesetzt, damit auch Tastatur-/Controller-Eingaben
-- waehrend der Fahrt nicht zum Aussteigen fuehren.
CreateThread(function()
    while true do
        if buckled and curVeh ~= 0 then
            DisableControlAction(0, 75, true) -- INPUT_VEH_EXIT
            Wait(0)
        else
            Wait(100)
        end
    end
end)

CreateThread(function()
    while true do
        Wait(100)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local eligible = veh ~= 0 and isEligible(veh) and not IsEntityDead(ped)

        if eligible then
            if veh ~= curVeh then
                -- neu eingestiegen: Warnung rechts anzeigen
                curVeh = veh
                if buckled then setBuckled(false, true) end
                local t = texts()
                ui('sb:warn', {
                    title = t.title,
                    text = fill(t.text),
                    key = cfg.Key,
                    duration = cfg.WarnDuration
                })
                lastBeep = 0
            end

            if cfg.BlockWindscreen then
                SetPedConfigFlag(ped, 32, not buckled)
            end

            if not buckled then
                local now = GetGameTimer()
                local engineOk = (not cfg.RequireEngine) or GetIsVehicleEngineRunning(veh)
                -- Erst warnen, wenn das Fahrzeug wirklich rollt (mindestens 5 km/h).
                -- cfg.MinSpeed kann den Grenzwert weiter erhoehen, aber nicht auf 0 senken.
                local warningSpeed = math.max(5.0, tonumber(cfg.MinSpeed) or 0)
                local speedOk = (GetEntitySpeed(veh) * 3.6) >= warningSpeed
                if engineOk and speedOk and now - lastBeep >= cfg.BeepInterval then
                    lastBeep = now
                    ui('sb:beep', { volume = cfg.Volume })
                end
            end
        elseif curVeh ~= 0 then
            -- Fahrzeug verlassen
            curVeh = 0
            if buckled then setBuckled(false, true) end
            SetPedConfigFlag(ped, 32, true)
            ui('sb:hide')
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SetPedConfigFlag(PlayerPedId(), 32, true)
    LocalPlayer.state:set('seatbelt', false, true)
end)
