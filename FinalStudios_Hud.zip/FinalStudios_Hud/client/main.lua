local ESX = exports['es_extended']:getSharedObject()

local KVP = 'me_hud:layout'

local loaded = false
local editing = false

local state = {
    hunger = 100,
    thirst = 100,
    cash = 0,
    bank = 0,
    job = '', grade = '',
    job2 = '', grade2 = '',
    players = 0,
    maxPlayers = 0
}

local minimap = {
    shape = Config.Minimap.shape == 'round' and 'round' or 'square',
    onlyVehicle = Config.Minimap.onlyVehicle == true
}
local shapeApplied = nil
local speedUnit = Config.SpeedUnit == 'mph' and 'mph' or 'kmh'


local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

local function round(v)
    return math.floor(v + 0.5)
end


local function readAccounts(accounts)
    for _, acc in pairs(accounts or {}) do
        if acc.name == Config.Accounts.cash then
            state.cash = acc.money or 0
        elseif acc.name == Config.Accounts.bank then
            state.bank = acc.money or 0
        end
    end
end

local function jobText(job)

    if not job or not (job.name or job.label) then return 'Arbeitslos', '' end
    if Config.HideUnemployed and job.name == Config.UnemployedJob then return '', '' end
    local grade = job.grade_label or ''
    if Config.ShowGradeNumber and job.grade ~= nil and job.name ~= Config.UnemployedJob then
        grade = (grade ~= '' and (grade .. ' ') or '') .. '[' .. tostring(job.grade) .. ']'
    end
    return job.label or job.name, grade
end

local function readJob(job)
    state.job, state.grade = jobText(job)
end

local function readJob2(job)
    
    if not job or job.name == Config.UnemployedJob then
        state.job2, state.grade2 = '', ''
        return
    end
    state.job2, state.grade2 = jobText(job)
end

local function isLoaded()
    if loaded then return true end
    if ESX.IsPlayerLoaded and ESX.IsPlayerLoaded() then
        loaded = true
        local data = ESX.GetPlayerData()
        readAccounts(data.accounts)
        readJob(data.job)
        readJob2(data.job2)
        TriggerServerEvent('me_hud:requestPlayers')
    end
    return loaded
end

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    loaded = true
    if xPlayer then
        readAccounts(xPlayer.accounts)
        readJob(xPlayer.job)
        readJob2(xPlayer.job2)
    end
    TriggerServerEvent('me_hud:requestPlayers')
end)

RegisterNetEvent('esx:onPlayerLogout', function()
    loaded = false
end)

RegisterNetEvent('esx:setAccountMoney', function(account)
    if not account then return end
    if account.name == Config.Accounts.cash then
        state.cash = account.money or 0
    elseif account.name == Config.Accounts.bank then
        state.bank = account.money or 0
    end
end)

RegisterNetEvent('esx:setJob', function(job)
    readJob(job)
end)

RegisterNetEvent('esx:setJob2', function(job)
    readJob2(job)
end)


CreateThread(function()
    while true do
        Wait(4000)
        if loaded then
            local ok, data = pcall(ESX.GetPlayerData)
            if ok and type(data) == 'table' then
                readJob(data.job)
                readJob2(data.job2)
            end
        end
    end
end)


local statusSeen = { hunger = {}, thirst = {} }
local STATUS_WINDOW = 2500

local function statusPercent(s)
    if type(s) ~= 'table' then return nil end
    local p
    if type(s.getPercent) == 'function' then
        local ok, res = pcall(s.getPercent)
        if ok then p = tonumber(res) end
    end
    if not p then p = tonumber(s.percent) end
    if not p then return nil end
    return clamp(p, 0.0, 100.0)
end

local function feedStatus(name, p)
    local list = statusSeen[name]
    if not list or p == nil then return end
    list[#list + 1] = { p = p, t = GetGameTimer() }
    if #list > 30 then table.remove(list, 1) end
end

local function resolveStatus(name)
    local list = statusSeen[name]
    local now = GetGameTimer()
    local pickLow = Config.StatusPick == 'low'
    local best
    for i = #list, 1, -1 do
        local e = list[i]
        if now - e.t > STATUS_WINDOW then
            table.remove(list, i)
        elseif best == nil or (pickLow and e.p < best) or (not pickLow and e.p > best) then
            best = e.p
        end
    end
    return best
end

AddEventHandler('esx_status:onTick', function(data)
    for _, s in pairs(data or {}) do
        if type(s) == 'table' and (s.name == 'hunger' or s.name == 'thirst') then
            feedStatus(s.name, statusPercent(s))
        end
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        if loaded then
            for _, name in ipairs({ 'hunger', 'thirst' }) do
                TriggerEvent('esx_status:getStatus', name, function(status)
                    feedStatus(name, statusPercent(status))
                end)
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(250)
        local h = resolveStatus('hunger')
        local t = resolveStatus('thirst')
        if h then state.hunger = clamp(round(h), 0, 100) end
        if t then state.thirst = clamp(round(t), 0, 100) end
    end
end)

RegisterNetEvent('me_hud:players', function(count, max)
    state.players = count or 0
    state.maxPlayers = max or 0
end)



local roundMaskReady = false
local roundMaskTried = false

local function ensureRoundMask()
    if roundMaskTried then return roundMaskReady end
    roundMaskTried = true
    local ok = pcall(function()
        local txd = CreateRuntimeTxd('me_hud_circle')
        CreateRuntimeTextureFromImage(txd, 'radarmasksm', 'html/img/circlemask.png')
    end)
    roundMaskReady = ok
    return ok
end

local function setSquareMinimap()
    pcall(RemoveReplaceTexture, 'platform:/textures/graphics', 'radarmasksm')
    SetMinimapClipType(0)
    SetMinimapComponentPosition('minimap', 'L', 'B', -0.0045, 0.002, 0.150, 0.188888)
    SetMinimapComponentPosition('minimap_mask', 'L', 'B', 0.020, 0.032, 0.111, 0.159)
    SetMinimapComponentPosition('minimap_blur', 'L', 'B', -0.03, 0.022, 0.266, 0.237)
end

local function roundScale()
    return clamp(tonumber(Config.Minimap.roundScale) or 0.6, 0.5, 1.2)
end

local function setRoundMinimap()
    local k = roundScale()
    local x = 0.004
    AddReplaceTexture('platform:/textures/graphics', 'radarmasksm', 'me_hud_circle', 'radarmasksm')
    SetMinimapClipType(1)
    SetMinimapComponentPosition('minimap', 'L', 'B', x, -0.047 * k, 0.1638 * k, 0.183 * k)
    SetMinimapComponentPosition('minimap_mask', 'L', 'B', x, 0.0, 0.128 * k, 0.20 * k)
    SetMinimapComponentPosition('minimap_blur', 'L', 'B', x - 0.01 * k, 0.025 * k, 0.262 * k, 0.300 * k)
end

local mmPending, mmBusy = nil, false


local function applyMinimap(shape)
    mmPending = shape
    if mmBusy then return end
    mmBusy = true
    CreateThread(function()
        while mmPending do
            local s = mmPending
            mmPending = nil
            if s == 'round' and ensureRoundMask() then
                setRoundMinimap()
            else
                setSquareMinimap()
            end
            
            SetBigmapActive(true, false)
            Wait(0)
            SetBigmapActive(false, false)
            Wait(150)
        end
        mmBusy = false
    end)
end

local function setMinimap(shape, onlyVehicle)
    shape = shape == 'round' and 'round' or 'square'
    minimap.onlyVehicle = onlyVehicle == true
    if shape ~= shapeApplied then
        shapeApplied = shape
        minimap.shape = shape
        applyMinimap(shape)
    end
end


local function getMinimapRect()
    local safezone = GetSafeZoneSize()
    local aspect = GetAspectRatio(false)
    local offset = math.abs(safezone - 1.0) * 10
    local left = (1.0 / 20.0) * offset
    local bottom = 1.0 - (1.0 / 20.0) * offset
    local width = 1.0 / (4 * aspect)
    local height = 1.0 / 5.674
    if minimap.shape == 'round' then
        local d = 0.19 * roundScale()
        width = d / aspect
        height = d
        left = left + 0.004
    end
    return {
        l = round(left * 10000) / 10000,
        t = round((bottom - height) * 10000) / 10000,
        r = round((left + width) * 10000) / 10000,
        b = round(bottom * 10000) / 10000
    }
end



local function loadLayout()
    local raw = GetResourceKvpString(KVP)
    if not raw then return nil end
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == 'table' then return data end
    return nil
end

RegisterNUICallback('ready', function(_, cb)
    local layout = loadLayout()
    local mm = layout and layout.minimap or nil
    local shape = Config.Minimap.shape
    local onlyVehicle = Config.Minimap.onlyVehicle
    if mm then
        if mm.shape then shape = mm.shape end
        if mm.onlyVehicle ~= nil then onlyVehicle = mm.onlyVehicle end
    end
    setMinimap(shape, onlyVehicle)

    if layout and type(layout.style) == 'table' and layout.style.unit then
        speedUnit = layout.style.unit == 'mph' and 'mph' or 'kmh'
    end

    SendNUIMessage({
        action = 'init',
        language = Config.Language or 'de',
        defaults = Config.Defaults,
        defaultMinimap = Config.Minimap,
        layout = layout,
        clockMode = Config.ClockMode,
        speedUnit = speedUnit,
        showMax = Config.ShowMaxPlayers,
        showName = Config.ShowServerName,
        serverName = Config.ServerName
    })
    cb('ok')
end)

local closedAt = 0

local function closeEdit()
    editing = false
    closedAt = GetGameTimer()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'edit', state = false })
end

RegisterNUICallback('save', function(data, cb)
    if type(data) == 'table' then
        SetResourceKvp(KVP, json.encode(data))
        if type(data.minimap) == 'table' then
            setMinimap(data.minimap.shape, data.minimap.onlyVehicle)
        end
        if type(data.style) == 'table' and data.style.unit then
            speedUnit = data.style.unit == 'mph' and 'mph' or 'kmh'
        end
    end
    closeEdit()
    cb('ok')
end)

RegisterNUICallback('minimap', function(data, cb)
    if type(data) == 'table' then
        setMinimap(data.shape, data.onlyVehicle)
    end
    cb('ok')
end)

RegisterNUICallback('unit', function(data, cb)
    if type(data) == 'table' and data.unit then
        speedUnit = data.unit == 'mph' and 'mph' or 'kmh'
    end
    cb('ok')
end)

RegisterNUICallback('close', function(_, cb)
    closeEdit()
    cb('ok')
end)

RegisterCommand(Config.Command, function()
   
    if editing then
        closeEdit()
        return
    end
    if not isLoaded() then return end
    editing = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'edit', state = true })
end, false)


CreateThread(function()
    while true do
        if editing then
            DisableAllControlActions(0)
           
            if IsPauseMenuActive() then
                SetFrontendActive(false)
                closeEdit()
            end
            Wait(0)
        elseif GetGameTimer() - closedAt < 500 then
            DisableControlAction(0, 199, true)
            DisableControlAction(0, 200, true)
            Wait(0)
        else
            Wait(250)
        end
    end
end)

CreateThread(function()
    Wait(1500)
    TriggerEvent('chat:addSuggestion', '/' .. Config.Command, (Config.Language == 'en' and 'Customize HUD (position, size, color, design, minimap)' or Config.Language == 'fr' and 'Personnaliser le HUD (position, taille, couleur, style, minicarte)' or Config.Language == 'es' and 'Personalizar HUD (posición, tamaño, color, diseño, minimapa)' or Config.Language == 'pl' and 'Dostosuj HUD (pozycja, rozmiar, kolor, styl, minimapa)' or 'HUD anpassen (Position, Größe, Farbe, Design, Minimap)'))
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    setSquareMinimap()
end)


CreateThread(function()
    Wait(500)
    if not shapeApplied then
        setMinimap(minimap.shape, minimap.onlyVehicle)
    end
end)



CreateThread(function()
    while true do
        for i = 1, #Config.HideComponents do
            HideHudComponentThisFrame(Config.HideComponents[i])
        end
        Wait(0)
    end
end)



local NO_GEAR_CLASSES = { [13] = true, [14] = true, [15] = true, [16] = true, [21] = true }

local function getVehicleData(veh)
    local mult = speedUnit == 'mph' and 2.236936 or 3.6
    local engineOn = GetIsVehicleEngineRunning(veh)

    local gear = ''
    if not NO_GEAR_CLASSES[GetVehicleClass(veh)] then
        local g = GetVehicleCurrentGear(veh)
        if not engineOn then
            gear = 'N'
        elseif g == 0 then
            gear = 'R'
        else
            gear = tostring(g)
        end
    end

    local _, lightsOn, highBeams = GetVehicleLightsState(veh)
    local lights = 0
    if highBeams == 1 then
        lights = 2
    elseif lightsOn == 1 then
        lights = 1
    end

    local ind = 0
    local ok, res = pcall(GetVehicleIndicatorLights, veh)
    if ok and type(res) == 'number' then ind = math.floor(res) end

    return {
        speed = round(GetEntitySpeed(veh) * mult),
        rpm = clamp(round(GetVehicleCurrentRpm(veh) * 100), 0, 100),
        gear = gear,
        fuel = Config.ShowFuel and clamp(round(GetVehicleFuelLevel(veh)), 0, 100) or -1,
        engine = clamp(round(GetVehicleEngineHealth(veh) / 10), 0, 100),
        body = clamp(round(GetVehicleBodyHealth(veh) / 10), 0, 100),
        indL = (ind & 1) ~= 0,
        indR = (ind & 2) ~= 0,
        lights = lights,
        engineOn = engineOn and true or false,
        locked = GetVehicleDoorLockStatus(veh) >= 2
    }
end



local lastPayload = nil
local interval = Config.UpdateInterval

CreateThread(function()
    while true do
        Wait(interval)

        local ready = isLoaded()
        local ped = PlayerPedId()
        local visible = ready and not IsPauseMenuActive()

        local veh = GetVehiclePedIsIn(ped, false)
        local inVehicle = veh ~= 0
        interval = inVehicle and Config.VehicleUpdateInterval or Config.UpdateInterval

        local talking, voiceMode, radio = false, 0, -1
        if Config.Voice == 'pma-voice' then
            talking = MumbleIsPlayerTalking(PlayerId()) or NetworkIsPlayerTalking(PlayerId())
            voiceMode = 2
            local prox = LocalPlayer.state.proximity
            if prox and prox.index then voiceMode = clamp(prox.index, 1, 3) end
            radio = LocalPlayer.state.radioChannel or 0
        end

        local timeStr, dateStr = '', ''
        if Config.ClockMode == 'game' then
            timeStr = string.format('%02d:%02d', GetClockHours(), GetClockMinutes())
            dateStr = string.format('%02d.%02d.%04d', GetClockDayOfMonth(), GetClockMonth() + 1, GetClockYear())
        end

        if Config.ManageRadar then
            DisplayRadar(visible and (not minimap.onlyVehicle or inVehicle))
        end

        local data = {
            visible = visible,
            id = GetPlayerServerId(PlayerId()),
            players = state.players,
            maxPlayers = state.maxPlayers,
            hunger = state.hunger,
            thirst = state.thirst,
            cash = state.cash,
            bank = state.bank,
            job = state.job,
            grade = state.grade,
            job2 = state.job2,
            grade2 = state.grade2,
            talking = talking,
            voiceMode = voiceMode,
            radio = radio,
            inVehicle = inVehicle,
            veh = inVehicle and getVehicleData(veh) or nil,
            time = timeStr,
            date = dateStr,
            mm = getMinimapRect()
        }

        local payload = json.encode(data)
        if payload ~= lastPayload then
            lastPayload = payload
            SendNUIMessage({ action = 'update', data = data })
        end
    end
end)
